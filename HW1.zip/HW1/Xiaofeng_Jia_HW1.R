
# Your Name: Xiaofeng Jia C12182911
#MAS 627 Programming for Data Analytics
#Professor: Doug Lehmann


setwd("/Users/crazycat/Documents/academic/5th year/MAS 627 R/HW1")

#-------------------------------------------------------
# Part 1

library(dplyr)

superstore = read.csv('https://dxl-datasets.s3.amazonaws.com/data/superstore.csv')

#1. What is the dimension of this data set? 

dim(superstore)
#Answer: [1] 9994   10
  

#2. What variables does it contain?

ls(superstore)
# [1] "Category" "Date"     "Discount" "ID"       "Profit"  
#[6] "Quantity" "Region"   "Sales"    "Segment"  "State"   

#3. What is the mean order size (Sales)?

mean(superstore$Sales)
#Answer: 229.858

#4. How many orders were made in the south region?

sum(superstore$Quantity[superstore$Region == 'South'])

#Answer = 6209

#5. Use the table() function to see how many orders have been made in each region.

table(superstore$Region, superstore$Quantity)

#6. What percent of orders were made in Florida?

sum(superstore$State == 'Florida')/nrow(superstore)

#Answers: 0.03832299

#7. What is the total profit from orders in Florida?

sum(superstore$Profit[superstore$State == 'Florida'])

#Answer:-3399.302


#8. Return all orders from Florida for Furniture that resulted in above average profit.


subset(superstore, superstore$Category == 'Furniture' & superstore$State == 'Florida' & superstore$Profit > mean(superstore$Profit))


#9. Convert Date to a date variable
library(stringr)
library(lubridate)

superstore$Date = mdy(superstore$Date)

str(superstore)

#10. Add a column for order year.
superstore$Year = year(superstore$Date)


#11. Calculate the total sales by year and display in a barplot.

barplot(tapply(superstore$Sales, superstore$Year, sum))


#12. Calculate the total sales by year in Florida and display in a barplot.


barplot(tapply(superstore$Sales[superstore$State == 'Florida'], superstore$Year[superstore$State == 'Florida'], sum))






# Part 2

# * Data comes from this Wiki page - https://en.wikipedia.org/wiki/List_of_largest_Internet_companies
# * Lists the largest internet companies, ordered by revenue
# * Convert the data into the format given below.
# * Pay attention to variable types.
# * HINT: Note that 4 observations in the Employees column have " (2019)" at the end, and should be removed before converting to numeric.




data = read.csv('https://dxl-datasets.s3.amazonaws.com/data/largest_internet_companies2023.csv')

# CODE TO CLEAN DATA HERE
library(stringr)
str(data)
data$Revenue.USD.Billions=str_remove_all(data$Revenue.USD.Billions, '\\$')
data$Revenue.USD.Billions = as.numeric(data$Revenue.USD.Billions)
str(data)

str_remove_all(data$Employees, '\\(2019\\)')


data$Employees = str_remove_all(data$Employees, '\\(2019\\)')
data$Employees = str_remove_all(data$Employees, '\\,')

data$Employees = as.numeric(data$Employees)

str(data)

data$Market.cap. =str_remove_all(data$Market.cap., '\\$')
data$Market.cap. =str_remove_all(data$Market.cap., '\\,')
data$Market.cap. =str_remove_all(data$Market.cap., '\\-')
data$Market.cap. = as.numeric(data$Market.cap.)

str(data)

library("dplyr")

data = data %>%
  rename('Revenue' = 'Revenue.USD.Billions',
         'FiscalYear' = 'Fiscal.Year',
          'MarketCap' = 'Market.cap.')
str(data)
head(data)

### Additional Questions:
#1. How many companies have a ".com" in their company name?

sum(str_detect(data$Company, '.com'))

#Answer: 7

#2. What proportion of these companies are in the Travel industry?

sum(data$Industry == 'Travel')/nrow(data)

#Answer: 0.04716981


#3. How many employees are employed by the 10 largest internet companies (by revenue)? Note that the data is already sorted high to low by revenue.



a = subset(data, Industry == 'Internet')
a = a[c(1, 2, 3, 4, 5, 6, 7, 8 ,9 ,10), ]

sum(a$Employees)

#Answer: 398249

#4. What percent of employees on the list work in the travel industry?

b = subset(data, Industry == 'Travel')

sum(b$Employees)/sum(data$Employees)

#Answer: 0.02089793


# Part 3
# The data for Part 3 represents the Miami Dolphins schedule page from ESPN, 
# located here - https://www.espn.com/nfl/team/schedule/_/name/mia. It looks a bit hectic when you read it in, but if you look at it online you should see what is going on - Preseason stuff at the bottom, Regular season at top. You need to extract and clean the regular season table.

# Don't be afraid of trial and error. You can always re-read in the dataset if you accidentally overwrite something.
# vs/@ in the Opponent variable corresponds with Home/Away

data = read.csv('https://dxl-datasets.s3.amazonaws.com/data/dolphins2023.csv')

# DATA CLEANING CODE HERE
data2 = data[-c(1, 2, 3, 4, 5, 6, 7, 17), -c(7, 8) ]

data2 = data2 %>%
  select(WK = X1,
         DATE = X2,
         OPPONENT = X3,
         TIME = X4,
         TV = X5,
         tickets = X6)

#alternetive
data2 = data2 %>%
  rename('WK' = 'X1',
         'DATE' = 'X2',
         'OPPONENT' = 'X3',
         'TIME' = 'X4',
         'TV' = 'X5',
         'tickets' = 'X6')


str(data2)

data2$tickets = str_remove_all(data2$tickets, 'Tickets as low as \\$')

data2$tickets = as.numeric(data2$tickets)
                               

data2 = data2 %>%
  mutate(
    LOCATION = ifelse(str_detect(OPPONENT, '\\@'), 'Away', 'Home '),
    LOCATION = ifelse(str_detect(OPPONENT, 'vs'), 'Home', 'Away'),
  )


data2$OPPONENT = str_remove_all(data2$OPPONENT, 'vs')

data2$OPPONENT = str_remove_all(data2$OPPONENT, '\\@')

str(data2)

                        
                        
  


                  

